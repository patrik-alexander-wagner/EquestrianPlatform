# Handoff: Livery Report Page — StableMaster

A design handoff package for rebuilding the **Livery Reports** page inside the
existing StableMaster app (UAE-based equestrian/livery management system).

---

## 1. Overview

The Livery Reports page is the operational + business dashboard for a stable
master. It aggregates real-time stable occupancy, customer/agreement counts,
revenue, top customer, monthly arrivals/departures, a 12-month revenue trend
chart, and a searchable roster of every active livery agreement.

Currently, the report is produced as a 9-page PDF (see
`source-data/livery-report-2026-05.pdf`). This redesign turns it into a fully
interactive in-app page, with the same content + extra business KPIs.

---

## 2. About the Design Files

The HTML file in this bundle (`livery-report-reference.html`) is a
**design reference**, not production code. It is a working prototype showing
the intended look, layout, behaviour, and copy.

Your task is to **recreate this page inside the StableMaster codebase**, using
its existing framework, component library, and design tokens — not to copy the
HTML directly.

Open `livery-report-reference.html` in any browser to interact with the
prototype. Resize the window to see responsive behaviour. The chart, search,
filters, and toggles all work.

> If the target codebase doesn't yet have a chart component, install a
> lightweight library (e.g. Recharts for React, Chart.js, or ECharts) — see
> §10 "Charts" for what's needed. Don't ship the hand-rolled SVG in the
> reference; it's there to specify the visual, not the implementation.

---

## 3. Fidelity

**High-fidelity.** Colours, type, spacing, and component shapes are final and
match the existing StableMaster aesthetic shown in
`existing-system-screenshots/`. The developer should reproduce the design
pixel-accurately using the codebase's existing components.

If your codebase already has a `Card`, `Button`, `Badge`, `Select`, `Input`,
or table component — **use those**. The tokens in §11 will guide colour /
spacing / radius for any new components.

---

## 4. Where this page lives in the app

- Route: `/reports/livery` (or whatever your reports section uses)
- Sidebar group: **Reports** → **Livery Reports** (active state in screenshot)
- Layout: same shell as the rest of the app — left sidebar + topbar + main
  content area (white surface on a `#F8F9FA` background)

The reference HTML includes the sidebar + topbar for visual context only.
**Do not rebuild the sidebar/topbar/avatar** — reuse the existing app shell;
just render the page contents inside the existing layout slot.

---

## 5. Page structure (top → bottom)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  TOPBAR (existing app shell — adds one button)                          │
│  [breadcrumb: Reports › Livery Report · May 2026]   [⚙][🖨][PDF btn][AD]│
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Livery Report                                                          │
│  Operational and business performance for May 2026                      │
│  [📅 May 2026 ▾]  [Generated 14 May 2026]                               │
│                                                                         │
│  ── Operational Overview ──                                             │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐              │
│  │ Total       │ ADEC Horses │ Customer    │ Occupancy   │              │
│  │ Checked-In  │ (On-Site)   │ Livery      │ Rate        │              │
│  └─────────────┴─────────────┴─────────────┴─────────────┘              │
│                                                                         │
│  ── Business Performance ──                                             │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐              │
│  │ Active      │ Active      │ Monthly     │ Top         │              │
│  │ Customers   │ Agreements  │ Revenue MTD │ Customer    │              │
│  └─────────────┴─────────────┴─────────────┴─────────────┘              │
│                                                                         │
│  ── Revenue & Movement ──                                               │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │ Revenue Breakdown:  Total | Livery | Service                    │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │ Revenue Trend (stacked bar chart)                               │    │
│  │ [Per Month · Last 12][Top 10 Customers][Bottom 10 Customers]    │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                         │
│  ── Customer Roster ──                                                  │
│  ┌──────────────────────────┬──────────────────────────┐                │
│  │ Arrivals — May 2026      │ Departures — May 2026    │                │
│  └──────────────────────────┴──────────────────────────┘                │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │ [search] [All][Damess][Al Anood][New in May]   [CSV][PDF]       │    │
│  │ Table: # | Customer | Box | Horse | Arrival | Departure | Pkg   │    │
│  │ Showing 57 of 57 agreements           Source: May 2026 report   │    │
│  └─────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Components — detailed spec

### 6.1 Page header

| Element | Spec |
|---|---|
| Title `<h1>` | "Livery Report" — 22px / 700 / `--text` / letter-spacing -0.005em |
| Subtitle `<p>` | "Operational and business performance for &lt;Month YYYY&gt;" — 13.5px / `--muted` |
| Month picker | A dropdown styled as a pill with calendar icon. Lists last 12 months. On change, refetch the report data for the selected month. **All dynamic content on the page rebinds to this month.** |
| Generated pill | Plain pill showing "Generated &lt;DD Mmm YYYY&gt;" (date the snapshot was produced). |

### 6.2 KPI cards (8 total, in 2 rows of 4)

All cards share the same shell:
- `background: #FFFFFF`
- `border: 1px solid #E5E7EB`
- `border-radius: 12px`
- `padding: 18px`
- `min-height: 124px`
- Hover: `border-color: #D1D5DB; box-shadow: 0 1px 2px rgba(17,24,39,.04)`

Structure inside each card:
1. **Row 1**: label (13px, `--muted`, weight 500) **left**, icon (20×20 outline) **right**
2. **Row 2**: big value (32px, weight 700, `--text`, tabular-nums, letter-spacing -0.015em)
3. **Row 3**: optional progress bar / legend / sublabel
4. **Footer row**: secondary text in `--muted`

**Row 1 — Operational Overview**

| # | Label | Value source | Notes |
|---|---|---|---|
| 1 | Total Checked-In Horses | `adecHorsesCount + customerHorsesCount` | Show a 6px-tall stacked bar below the number: navy (ADEC) + green (Customer). Legend below: "ADEC 24" / "Customer 56". Icon: horseshoe (green). |
| 2 | ADEC Horses (On-Site) | `adecHorsesCount` | Footer: "House-owned, in residence". Icon: shield/check (navy). |
| 3 | Customer Livery Horses | `customerHorsesCount` | Footer: "&lt;n&gt; new arrival(s) this month". Icon: people (green). |
| 4 | Occupancy Rate | `round(totalCheckedIn / totalCapacity × 100)` | Show as "81%" + 6px green progress bar at that width. Footer: "&lt;occupied&gt; / &lt;capacity&gt; boxes occupied". Icon: gauge (purple). |

**Row 2 — Business Performance**

| # | Label | Value source | Notes |
|---|---|---|---|
| 5 | Active Customers | distinct customers with at least 1 active agreement | Footer: "with active agreements". Icon: person (green). |
| 6 | Active Livery Agreements | count of active agreements excluding ADEC-owned horses | Footer: "excluding ADEC-owned". Icon: contract (orange). |
| 7 | Monthly Revenue (MTD) | sum of all posted invoices for the selected month | Format: `AED &lt;amount&gt;` with "AED" prefix small/muted. Footer: "Livery cycle posts &lt;15th&gt;" on left, **"Prev month: AED &lt;amount&gt;"** on right (right side bold-medium, `--text-2`). Icon: dollar circle (purple). |
| 8 | Top Customer (This Month) | customer with highest active monthly contract value | Render the **name** at 18px/700/`--navy` instead of a number; subline "&lt;n&gt; horses · AED &lt;monthly&gt; / mo" at 12.5px/`--muted`. Footer: "By active contract value". Icon: trophy (orange). |

> **No comparison/delta chips** anywhere except KPI #7 ("Prev month"). The
> earlier version had ↑↓ % vs last month on every card; that was removed
> by request. Don't reintroduce them.

### 6.3 Revenue Breakdown card

Single card with 3 equal cells separated by a 1px vertical divider:

| Cell | Label | Value | Note |
|---|---|---|---|
| 1 | Total Revenue | `liveryRevenue + serviceRevenue` | "All sources, posted to date" |
| 2 | Livery Revenue | sum of livery package invoices | "Cycle bills &lt;15 May&gt;" |
| 3 | Service Revenue | sum of all service line items | "Clinic, Farrier, Stores & Extras" |

> Was previously named **"Adhoc Revenue"** — renamed to **Service Revenue**
> with the categories spelled out in the note line.

Value format: `<span class="cur">AED</span>450.00` — the "AED" is 13px /
`--muted`, amount is 28px / weight 700 / `--text`, tabular numerals.

### 6.4 Revenue Trend chart

A stacked vertical bar chart inside a card.

- Title: "Revenue Trend"
- Sublabel: "Stacked: Livery + Service"
- **Toggle (segmented control)**: 3 options, only one active at a time
  - **Per Month · Last 12** — bars = months ending with the selected month (e.g. Jun 2025 → May 2026)
  - **Top 10 Customers** — bars = the 10 customers with highest monthly value, for the selected month
  - **Bottom 10 Customers** — bars = the 10 with lowest monthly value
- **Legend**: "Livery" (green `#1F9D55` swatch) and "Service" (navy `#1E3A5F` swatch), right-aligned in toolbar.
- Each bar is **stacked**: Livery at the bottom, Service on top. Rounded 3px corners.
- **Bar width**: ~72% of the slot width per data point (i.e. ~28% gap), so bars look solid, not thin.
- **Bar value label**: total `livery + service`, formatted in "K" suffix (`245K`, `30K`), placed 6px above the top of the stack.
- **MTD tag**: append " MTD" to the value label for the current month bar (no full livery cycle yet).
- **Y-axis**: 4 gridlines, "nice" tick steps using the 1/1.5/2/2.5/3/4/5/7.5/10 × 10ⁿ ladder so the scale always fits the data. Format ticks with `K` for ≥1000.
- **X-axis labels**: rotated −22° in customer modes (long names), horizontal in month mode.
- **Tooltip on bar hover**: dark pill showing label, Livery amount, Service amount, Total. Position follows cursor.

### 6.5 Arrivals & Departures cards

Two cards side-by-side, **inside** the Customer Roster section (above the
search toolbar).

**Arrivals — &lt;Month YYYY&gt;**
- Header sublabel: "&lt;n&gt; check-ins"
- Body: a list of `list-row` items, one per new arrival in the month:
  - 40×40 green rounded square (8px radius) with white horseshoe icon
  - Title (14px/700/`--navy`): `HORSE NAME (BREEDING NAME)`
  - Subtitle (12.5px/`--muted`): `<CUSTOMER_ID> <CUSTOMER NAME>` + a green outlined "New · &lt;date&gt;" badge
  - Right column: `AED &lt;package&gt;/mo` then small grey "Stable / Box-ID"

**Departures — &lt;Month YYYY&gt;**
- Header sublabel: "&lt;n&gt; check-outs"
- Body: same list-row pattern. **Empty state**: light grey square with a logout-arrow icon centred, and the line "No departures recorded this month."

### 6.6 Customer Roster

A card containing:

**Toolbar**:
- Search input (left, ~280px wide, icon prefix, placeholder "Search customer, horse or box...")
- Segmented filter control: `All (57)` · `Damess (23)` · `Al Anood (34)` · `New in May`
  - Counts in parens are live counts based on the current data.
- Right side: `Download CSV` and `Download PDF` outlined buttons (icons + text)

**Table**:
| Column | Width | Content / format |
|---|---|---|
| `#` | 42px | index, 12px/`--muted` |
| Customer | flex | 32×32 green icon + name (`--navy`, 600, 13.5px) on top, `CUS-XXXXX` underneath in 11.5px/`--muted`. Append a "New" badge if arrived this month. |
| Box | auto | stable name (e.g. "Damess") on top in `--text-2`, box ID (e.g. "SB001-S014") underneath in 11.5px/`--muted` (mono-feeling). |
| Horse | flex | horse short name + italic breeding name on a second line. |
| Arrival | auto | "1 May 2026" / `--muted` / nowrap |
| Departure | auto | "—" placeholder if open. `--muted-2`. |
| Package | right-aligned | `AED 5,999.00 /mo` — amount in 600 weight tabular-nums, " /mo" in 11.5px/`--muted` |

Row hover: `background: #FAFBFC`.

**Footer of card**: left "Showing &lt;n&gt; of &lt;total&gt; agreements", right "Source: Livery Report · &lt;Month YYYY&gt;".

---

## 7. Interactions

| Trigger | Action |
|---|---|
| Month picker change | Refetch all data for that month; update every value, the chart, the arrivals/departures lists, the roster, and the report-title period label. |
| Roster search input | Live filter rows on customer name, customer ID, box name, box ID, horse name, breeding name (case-insensitive substring). |
| Roster segmented filter | Filter rows by stable (`damess` / `anood`) or by `new` tag (rows tagged as new this month). |
| Chart segmented toggle | Re-render the chart with the selected dataset. Show appropriate axis labels. |
| Bar hover | Show tooltip near cursor with detailed numbers. |
| "Download Complete Report (PDF)" (topbar) | Server-side generates the full report PDF (matches the format in `source-data/livery-report-2026-05.pdf` but with the redesigned KPIs at top, then the existing pages). |
| "Download CSV" (roster) | Export the currently filtered roster as CSV. |
| "Download PDF" (roster) | Export the currently filtered roster as PDF. |
| Print icon (topbar) | `window.print()` — page should use the existing print stylesheet. |

---

## 8. Data — what to fetch

Build one endpoint that returns everything the page needs for a given month, or split per section. Suggested shape:

```ts
GET /api/reports/livery?month=2026-05  ->  LiveryReport

type LiveryReport = {
  month: string;            // "2026-05"
  generatedAt: string;      // ISO date
  operational: {
    totalCheckedIn: number;
    adecHorses: number;
    customerHorses: number;
    occupancyRate: number;   // 0-100
    totalCapacity: number;   // for ratio display "80 / 99"
    arrivalsThisMonth: number;
  };
  business: {
    activeCustomers: number;
    activeAgreements: number; // excludes ADEC
    revenueMTD: number;
    revenuePrevMonth: number;
    topCustomer: { name: string; horses: number; monthlyValue: number; };
  };
  revenue: {
    total: number;
    livery: number;
    service: number;          // was "adhoc"
    liveryCycleDay: number;   // e.g. 15
  };
  trends: {
    perMonth: Array<{ label: string; livery: number; service: number; mtd?: boolean }>; // last 12 incl. current
    topCustomers: Array<{ label: string; livery: number; service: number }>;             // top 10
    bottomCustomers: Array<{ label: string; livery: number; service: number }>;          // bottom 10
  };
  arrivals: Array<RosterEntry>;       // entries with arrival in selected month
  departures: Array<RosterEntry>;     // entries with departure in selected month
  roster: Array<RosterEntry>;         // all active agreements
};

type RosterEntry = {
  index: number;
  customerId: string;          // "CUS-00128"
  customerName: string;
  stable: string;              // "Damess" / "Al Anood"
  boxId: string;               // "SB001-S014"
  horseName: string | null;    // "GRETZKY"
  breedingName: string | null; // "GRETZKY"
  arrivalDate: string;         // ISO
  departureDate: string | null;
  packageMonthly: number;      // AED
  tags: string[];              // ["new", "damess", "anood"]
};
```

The reference HTML has the May 2026 roster (57 records) hardcoded in JS — see
`livery-report-reference.html` near "`const roster = [`" — so you can use it as
seed data while wiring up the API.

---

## 9. Where the data comes from (business logic)

| Field | Calculation |
|---|---|
| `totalCheckedIn` | `adecHorses + customerHorses` |
| `adecHorses` | `Horses.where(ownerType = 'ADEC' AND status = 'on_site').count` |
| `customerHorses` | distinct horses on an active livery agreement (excluding test rows like `SB003-T006`) |
| `activeCustomers` | distinct customers with ≥ 1 active agreement |
| `activeAgreements` | active agreements where `horse.ownerType ≠ 'ADEC'` |
| `revenueMTD` | sum of all invoiced amounts (livery + service) posted within the selected month |
| `revenuePrevMonth` | same, for the previous month |
| `topCustomer` | the customer with the highest **active monthly contract value** (sum of package rates across their horses), tie-break by name. **Not** by MTD billed revenue — early in the month MTD is too sparse to be meaningful. |
| `trends.perMonth` | revenue grouped by month for the 12 months ending with `month`. Current month is marked `mtd: true`. |
| `trends.topCustomers` / `bottomCustomers` | customers sorted by total billed in the selected month |

---

## 10. Charts

The reference uses hand-rolled SVG. **For production, install a real library.**
Whatever your codebase uses is fine, as long as it supports stacked vertical
bars + tooltips + custom legend. Examples:

- **React + Recharts**: `<BarChart>` with two `<Bar>` series stacked by setting
  `stackId="a"` — straightforward.
- **Chart.js**: `type: 'bar'` with `stacked: true` on x and y axes.
- **ECharts**: `series: [{type:'bar', stack:'rev'}, ...]`.

Requirements for the chart implementation:
- Bars rounded-top (3px radius).
- Bar width ~72% of category slot.
- Y-axis nice-rounded ticks; 4 horizontal gridlines.
- Total value label above each stack (formatted with K suffix, e.g. "245K").
- Append " MTD" for the current month label.
- Dark tooltip on hover (rounded 6px, white text, ~11.5px), showing label +
  Livery + Service + Total.
- Two series colours: Livery `#1F9D55`, Service `#1E3A5F`.
- Toggle segmented control above the chart (3 buttons) drives which dataset
  feeds the chart.

---

## 11. Design tokens

```css
/* Background / surface */
--bg:           #F8F9FA;
--surface:      #FFFFFF;
--surface-2:    #F4F5F7;

/* Borders */
--border:       #E5E7EB;
--border-soft:  #EEF0F2;

/* Text */
--text:         #111827;
--text-2:       #374151;
--muted:        #6B7280;
--muted-2:      #9CA3AF;

/* Brand */
--green:        #1F9D55;   /* primary emerald, matches existing app */
--green-700:    #167A40;
--green-50:     #E8F5EE;
--navy:         #1E3A5F;   /* link / horse-name color in lists */

/* Accents (KPI icons + status) */
--orange:       #D97706;
--orange-50:    #FEF3E6;
--blue:         #2563EB;
--blue-50:      #EBF2FE;
--purple:       #7C3AED;
--purple-50:    #F1ECFE;
--red:          #DC2626;
--red-50:       #FEECEC;

/* Shape */
--radius:       8px;
--radius-lg:    12px;
```

**Typography**:
- Body font family: `Geist, ui-sans-serif, sans-serif` (or your codebase's system sans if already set).
- Base size: 14px / line-height 1.5.
- Numbers in KPI values, table amounts, and chart axes: `font-variant-numeric: tabular-nums`.

**Spacing**: 4 / 8 / 12 / 16 / 18 / 22 / 28 / 32 px scale.

**Shadow (card hover)**: `0 1px 2px rgba(17,24,39,.04)`.

---

## 12. Icons

The reference uses inline outline SVG (stroke-width 2). Replace with whatever
icon set the rest of the app uses (e.g. Lucide, Phosphor, Heroicons —
outline variants). The icons used per element:

| Where | Icon |
|---|---|
| Sidebar item "Livery Reports" | bar-chart |
| Topbar — print | printer |
| Topbar — Download Complete Report (PDF) | file-down / file-text |
| KPI: Total Checked-In / Customer Horses | horse / horseshoe (or users) |
| KPI: ADEC Horses | shield-check |
| KPI: Customer Livery Horses | users |
| KPI: Occupancy | gauge |
| KPI: Active Customers | user |
| KPI: Active Agreements | file-text |
| KPI: Monthly Revenue | dollar-circle |
| KPI: Top Customer | trophy |
| Roster row | horseshoe (green chip) |
| Departures empty state | log-out arrow |
| Search input | search |
| Download CSV / PDF | download |
| Month picker | calendar |

---

## 13. Responsive behaviour

- ≥1200px: KPI grid 4-up, Arrivals+Departures 2-up.
- &lt;1200px: KPI grid 2-up, Arrivals+Departures 1-up (stacked).
- &lt;760px: Sidebar collapses to a sheet/hamburger (use the existing app's mobile pattern); content stacks to a single column.

The reference HTML already implements these breakpoints — see the `@media`
rules near the bottom of its `<style>` block.

---

## 14. Accessibility notes

- All interactive elements must be reachable by keyboard (Tab order matches visual order).
- Buttons in the segmented controls need `role="tab"` + `aria-selected` if you implement them as tabs; otherwise plain buttons are fine.
- Chart bars should expose data via an accessible `<table>` fallback (or `aria-label` on the chart container summarising the data).
- Colour contrast: green-700 `#167A40` for foreground text on green-50 `#E8F5EE` passes WCAG AA. Don't use plain `--green` for body text.

---

## 15. Files in this bundle

```
design_handoff_livery_report/
├── README.md                              ← you are here
├── livery-report-reference.html           ← interactive design reference
├── source-data/
│   └── livery-report-2026-05.pdf          ← original PDF (data source + content reference)
└── existing-system-screenshots/
    ├── 01-dashboard.png                   ← existing StableMaster dashboard (style match)
    ├── 02-new-agreement.png               ← existing "New Agreement" page
    └── 03-to-invoice.png                  ← existing "To Invoice" page (table / status patterns)
```

Use the existing-system screenshots to verify that the rebuilt page feels like
part of the same product — same sidebar, same card style, same green accent,
same row styling, same table density.

---

## 16. Acceptance checklist

When you're done, the page should:

- [ ] Render inside the existing StableMaster shell (sidebar + topbar) with **Livery Reports** highlighted in the sidebar.
- [ ] Show a working **month picker** that swaps every metric on the page.
- [ ] Display 8 KPI cards in two rows of 4 with **no comparison chips** (except "Prev month" line on Monthly Revenue).
- [ ] Display the Revenue Breakdown with **Service Revenue** (not "Adhoc"), noting *Clinic, Farrier, Stores & Extras*.
- [ ] Display the Revenue Trend stacked bar chart with three toggles: **Per Month · Last 12**, **Top 10 Customers**, **Bottom 10 Customers**. Y-axis must scale correctly for each dataset.
- [ ] Show Arrivals + Departures cards inside the Customer Roster section, with empty-state for Departures when none.
- [ ] Roster table is searchable, filterable, and exportable to **CSV** + **PDF**.
- [ ] Topbar has a **Download Complete Report (PDF)** button.
- [ ] Loading and error states for the data fetch are handled gracefully.
- [ ] All numeric values are tabular-aligned.

---

_If you spot anything unclear in this spec, stop and ask before guessing — the
reference HTML is authoritative for visuals._
