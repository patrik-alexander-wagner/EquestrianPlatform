# Handoff: Livery Report — StableMaster

A design handoff package for rebuilding the **Livery Reports** page inside
the existing StableMaster app (UAE-based equestrian livery management
system), plus a downloadable **complete-report PDF**.

This bundle contains:
1. **`livery-report-reference.html`** — interactive in-app page (browser view).
2. **`livery-report-pdf-reference.html`** — paginated A4 document for PDF export.
3. **`source-data/livery-report-2026-05.pdf`** — the original report (data source).
4. **`existing-system-screenshots/`** — for style match with the live app.

---

## 1. Overview

The Livery Reports screen is the operational + business dashboard for the
Stable Master. It aggregates real-time stable occupancy, customer/agreement
counts, revenue, top customer, monthly arrivals/departures, a 12-month
revenue trend chart, and a searchable roster of every active livery
agreement.

The same data also has to be exportable as a **printable PDF report** with
the same look (paginated A4 portrait — see `livery-report-pdf-reference.html`).

---

## 2. About the design files

The HTML files in this bundle are **design references**, not production code.
They are working prototypes showing the intended look, layout, behaviour,
and copy.

Your task is to **recreate these inside the StableMaster codebase**, using
its existing framework, component library, and design tokens — not to copy
the HTML directly.

Open the references in any browser to interact:
- `livery-report-reference.html` — has working chart, search, filters, toggles, month picker.
- `livery-report-pdf-reference.html` — has a floating "Print / Save PDF" button (top-right). Use Cmd/Ctrl+P → *Save as PDF* to produce the actual PDF.

> If the target codebase doesn't yet have a chart component, install a
> lightweight library (e.g. Recharts for React, Chart.js, ECharts) —
> see §10. Don't ship the hand-rolled SVG in the reference; it's there
> to specify the visual, not the implementation.

---

## 3. Fidelity

**High-fidelity.** Colours, type, spacing, and component shapes are final
and match the existing StableMaster aesthetic shown in
`existing-system-screenshots/`. Reproduce the design pixel-accurately using
the codebase's existing components.

If your codebase already has a `Card`, `Button`, `Badge`, `Select`,
`Input`, or table component — **use those**. The tokens in §11 will guide
colour / spacing / radius for any new components.

---

## 4. Page location

- Route: `/reports/livery` (or whatever the reports section uses)
- Sidebar group: **Reports** → **Livery Reports** (active state in screenshot)
- Layout: same shell as the rest of the app — left sidebar + topbar + main
  content area on a `#F8F9FA` background.

The reference HTML includes the sidebar + topbar for visual context only.
**Do not rebuild the sidebar/topbar/avatar** — reuse the existing app shell.

---

## 5. Page structure (top → bottom)

```
┌─────────────────────────────────────────────────────────────────────────┐
│  TOPBAR (existing app shell — adds one button)                          │
│  [Reports › Livery Report · May 2026] [⚙][🖨][Download Complete (PDF)][AD]│
├─────────────────────────────────────────────────────────────────────────┤
│  Livery Report                                                          │
│  Operational and business performance for May 2026                      │
│  [📅 May 2026 ▾]  [Generated 14 May 2026]                               │
│                                                                         │
│  ── Operational Overview ──                                             │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐              │
│  │ Total       │ ADEC Horses │ Customer    │ Occupancy   │              │
│  │ Checked-In  │             │ Livery      │ Rate        │              │
│  └─────────────┴─────────────┴─────────────┴─────────────┘              │
│                                                                         │
│  ── Business Performance ──                                             │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐              │
│  │ Active      │ Active      │ Monthly     │ Top         │              │
│  │ Customers   │ Agreements  │ Revenue MTD │ Customer    │              │
│  └─────────────┴─────────────┴─────────────┴─────────────┘              │
│                                                                         │
│  ── Revenue & Movement ──                                               │
│  ┌─ Revenue Breakdown ────────────────────────────────────────────┐     │
│  │  Total | Livery | Service                                      │     │
│  └────────────────────────────────────────────────────────────────┘     │
│  ┌─ Revenue Trend (stacked bar chart) ─────────────────────────────┐    │
│  │  [Per Month · Last 12] [Top 10 Customers] [Bottom 10 Customers] │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                         │
│  ── Customer Roster ──                                                  │
│  ┌─ Arrivals — May 2026 ──┐ ┌─ Departures — May 2026 ──┐                │
│  └────────────────────────┘ └──────────────────────────┘                │
│  ┌─ Roster ───────────────────────────────────────────────────────┐    │
│  │ [search] [All][Damess][Al Anood][New in May]   [CSV][PDF]      │    │
│  │ Table: # | Customer | Box | Horse | Arrival | Departure | Pkg  │    │
│  └────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Components — detailed spec

### 6.1 Page header

| Element | Spec |
|---|---|
| Title `<h1>` | "Livery Report" — 22px / 700 / `--text` / letter-spacing -0.005em |
| Subtitle `<p>` | "Operational and business performance for &lt;Month YYYY&gt;" — 13.5px / `--muted` |
| Month picker | Dropdown styled as a pill with calendar icon. Lists last 12 months. On change, refetch the report data for the selected month. **All dynamic content on the page rebinds to this month.** |
| Generated pill | Plain pill showing "Generated &lt;DD Mmm YYYY&gt;" (date the snapshot was produced). |

### 6.2 KPI cards (8 total, in 2 rows of 4)

Shared shell:
- `background: #FFFFFF`
- `border: 1px solid #E5E7EB`
- `border-radius: 12px`
- `padding: 18px`
- `min-height: 124px`
- Hover: `border-color: #D1D5DB; box-shadow: 0 1px 2px rgba(17,24,39,.04)`

Internal:
1. **Row 1**: label (13px, `--muted`, weight 500) on left, icon (20×20 outline) on right
2. **Row 2**: big value (32px, weight 700, tabular-nums, letter-spacing -0.015em)
3. **Row 3**: optional progress bar / legend / sublabel
4. **Footer row**: only used where indicated below

**No comparison / delta chips** anywhere. The earlier version had ↑↓ % vs
last month on every card; those were removed by request. Don't reintroduce.

**Row 1 — Operational Overview**

| # | Label | Value source | Card body / footer |
|---|---|---|---|
| 1 | Total Checked-In Horses | `adecHorses + customerHorses` | Below the number: 6px-tall stacked bar (navy ADEC + green Customer) and legend "ADEC 24" / "Customer 56". |
| 2 | ADEC Horses (On-Site) | `adecHorses` | **No footer.** Icon: shield/check (navy). |
| 3 | Customer Livery Horses | `customerHorses` | Footer: "&lt;n&gt; new arrival(s) this month". Icon: people (green). |
| 4 | Occupancy Rate | `round(totalCheckedIn / totalCapacity × 100)` | "81%" + 6px green progress bar. Footer: "&lt;occupied&gt; / &lt;capacity&gt; boxes occupied". Icon: gauge (purple). |

**Row 2 — Business Performance**

| # | Label | Value source | Card body / footer |
|---|---|---|---|
| 5 | Active Customers | distinct customers with ≥1 active agreement | **No footer.** Icon: person (green). |
| 6 | Active Livery Agreements | count of active agreements where horse is NOT ADEC-owned | **No footer.** Icon: contract (orange). |
| 7 | Monthly Revenue (MTD) | sum of invoiced amounts posted in selected month | Format: `AED <amount>` with "AED" prefix small/muted. **Footer: `Prev month: AED <amount>`** — only thing in footer. Icon: dollar circle (purple). |
| 8 | Top Customer (This Month) | customer with highest active monthly contract value | Render the **name** at 18px/700/`--navy`. Sublabel: "&lt;n&gt; horses · AED &lt;monthly&gt; / mo" at 12.5px/`--muted`. **No footer.** Icon: trophy (orange). |

### 6.3 Revenue Breakdown

Single card with 3 equal cells separated by 1px vertical dividers.

| Cell | Label | Value | Note line |
|---|---|---|---|
| 1 | Total Revenue | `liveryRevenue + serviceRevenue` | **"All sources"** |
| 2 | Livery Revenue | sum of livery package invoices for the month | **"Livery package"** |
| 3 | Service Revenue | sum of service line items | **"Clinic, Farrier, Stores & Extras"** |

> Was previously named "Adhoc Revenue" — renamed to **Service Revenue**.

Value format: `<span class="cur">AED</span>450.00` — "AED" is 13px /
`--muted`, amount is 28px / weight 700 / `--text`, tabular numerals.

### 6.4 Revenue Trend chart

Stacked vertical bar chart inside a card.

- Title: "Revenue Trend"
- Sublabel: "Stacked: Livery + Service"
- **Toggle (segmented control)** — 3 buttons, single-select:
  - **Per Month · Last 12** — bars = months ending with the selected month
  - **Top 10 Customers** — top 10 by monthly value for the selected month
  - **Bottom 10 Customers** — bottom 10
- **Legend**: "Livery" (green `#1F9D55`) and "Service" (navy `#1E3A5F`), right-aligned.
- Each bar is **stacked**: Livery at the bottom, Service on top. 3px corner radius.
- Bar width ~72% of slot.
- Total value label above each stack, K-suffixed (`245K`, `30K`). Append " MTD" on the current month bar.
- Y-axis: 4 gridlines, "nice" tick steps using the 1 / 1.5 / 2 / 2.5 / 3 / 4 / 5 / 7.5 / 10 × 10ⁿ ladder so the scale always fits the data. Tick labels K-suffixed.
- X-axis labels rotate −22° in customer modes (long names), horizontal in month mode.
- Tooltip on bar hover: dark pill with label, Livery, Service, Total.

### 6.5 Arrivals & Departures cards

Two cards side-by-side, **inside the Customer Roster section**, above the
search toolbar.

**Arrivals — &lt;Month YYYY&gt;**
- Header sublabel: "&lt;n&gt; check-ins"
- Body: list of rows, one per arrival:
  - 40×40 green rounded square (8px radius) with white horseshoe icon
  - Title 14px/700/`--navy`: `HORSE NAME (BREEDING NAME)`
  - Subtitle 12.5px/`--muted`: `<CUSTOMER_ID> <CUSTOMER NAME>` + green outlined "New · &lt;date&gt;" badge
  - Right column: `AED <package>/mo` then small grey "Stable / Box-ID"

**Departures — &lt;Month YYYY&gt;**
- Header sublabel: "&lt;n&gt; check-outs"
- Same row format. **Empty state**: light grey square + logout-arrow icon + line "No departures recorded this month."

### 6.6 Customer Roster

**Toolbar**:
- Search input (~280px wide, search-icon prefix, placeholder "Search customer, horse or box...")
- Segmented filter: `All (57)` · `Damess (23)` · `Al Anood (34)` · `New in May`
- Right: `Download CSV` and `Download PDF` outlined buttons (icon + text)

**Table columns**:

| Column | Width | Content |
|---|---|---|
| `#` | 42px | index, 12px/`--muted` |
| Customer | flex | 32×32 green icon + name (`--navy`, 600, 13.5px) over `CUS-XXXXX` in 11.5px/`--muted`. "New" badge if arrived this month. |
| Box | auto | Stable (e.g. "Damess") over box ID ("SB001-S014" in mono-feel `--muted`) |
| Horse | flex | Horse short name + italic breeding name on a second line |
| Arrival | auto | "1 May 2026" / `--muted` / nowrap |
| Departure | auto | "—" placeholder if open |
| Package | right-aligned | `AED 5,999.00 /mo` — amount in 600 weight tabular-nums, " /mo" in 11.5px/`--muted` |

Row hover: `background: #FAFBFC`.

**Footer**: left "Showing &lt;n&gt; of &lt;total&gt; agreements", right "Source: Livery Report · &lt;Month YYYY&gt;".

---

## 7. Interactions

| Trigger | Action |
|---|---|
| Month picker change | Refetch data, update every value, chart, lists, roster, and the report-title period. |
| Roster search input | Live filter rows on customer name, customer ID, box name, box ID, horse name, breeding name (case-insensitive substring). |
| Roster segmented filter | Filter by stable (`damess`/`anood`) or by `new` tag. |
| Chart segmented toggle | Re-render the chart with the selected dataset. |
| Bar hover | Tooltip near cursor. |
| **"Download Complete Report (PDF)"** (topbar) | Server generates the full report PDF — see §12. |
| Download CSV (roster) | Export filtered roster as CSV. |
| Download PDF (roster) | Export filtered roster as PDF. |
| Print icon (topbar) | `window.print()` — uses the existing print stylesheet. |

---

## 8. Data — API contract

```ts
GET /api/reports/livery?month=2026-05  →  LiveryReport

type LiveryReport = {
  month: string;            // "2026-05"
  generatedAt: string;      // ISO
  operational: {
    totalCheckedIn: number;
    adecHorses: number;
    customerHorses: number;
    occupancyRate: number;   // 0-100
    totalCapacity: number;   // e.g. 99
    arrivalsThisMonth: number;
  };
  business: {
    activeCustomers: number;
    activeAgreements: number; // excludes ADEC
    revenueMTD: number;
    revenuePrevMonth: number;
    topCustomer: { name: string; horses: number; monthlyValue: number };
  };
  revenue: {
    total: number;
    livery: number;
    service: number;          // was "adhoc"
  };
  trends: {
    perMonth: Array<{ label: string; livery: number; service: number; mtd?: boolean }>; // 12
    topCustomers: Array<{ label: string; livery: number; service: number }>;             // 10
    bottomCustomers: Array<{ label: string; livery: number; service: number }>;          // 10
  };
  arrivals:   Array<RosterEntry>; // entries with arrival in selected month
  departures: Array<RosterEntry>; // entries with departure in selected month
  roster:     Array<RosterEntry>; // all active agreements
  stables?:   Array<{ name: string; occupied: number; capacity: number }>; // for PDF capacity block
};

type RosterEntry = {
  index: number;
  customerId: string;          // "CUS-00128"
  customerName: string;
  stable: string;              // "Damess" / "Al Anood"
  boxId: string;               // "SB001-S014"
  horseName: string | null;
  breedingName: string | null;
  arrivalDate: string;         // ISO
  departureDate: string | null;
  packageMonthly: number;
  tags: string[];              // ["new", "damess", "anood"]
};
```

The reference HTML hard-codes the May 2026 roster (57 records) in JS — use
it as seed data while wiring the API.

---

## 9. Business logic

| Field | Calculation |
|---|---|
| `totalCheckedIn` | `adecHorses + customerHorses` |
| `adecHorses` | `Horses.where(ownerType = 'ADEC' AND status = 'on_site').count` |
| `customerHorses` | distinct horses on an active agreement (exclude test rows like `SB003-T006`) |
| `activeCustomers` | distinct customers with ≥1 active agreement |
| `activeAgreements` | active agreements where `horse.ownerType ≠ 'ADEC'` |
| `revenueMTD` | sum of all invoiced amounts (livery + service) posted within the selected month |
| `revenuePrevMonth` | same, for previous month |
| `topCustomer` | customer with highest **active monthly contract value** (sum of package rates across their horses) for the selected month; tie-break by name. **Not** by MTD billed revenue. |
| `trends.perMonth` | revenue grouped by month for the 12 months ending with `month`. Current month marked `mtd: true`. |
| `trends.topCustomers` / `bottomCustomers` | customers sorted by total billed in the selected month |

---

## 10. Charts

Reference uses hand-rolled SVG. **For production, install a real library.**
Use whatever fits the codebase — examples:

- **React + Recharts**: `<BarChart>` with `<Bar stackId="a">` × 2.
- **Chart.js**: `type: 'bar'` with `stacked: true` on x & y axes.
- **ECharts**: `series: [{type:'bar', stack:'rev'}, ...]`.

Requirements:
- Stacked vertical bars, 3px top radius.
- Bar width ~72% of category slot.
- Y-axis nice-rounded ticks, 4 horizontal gridlines, K-suffixed labels.
- Total label above each stack (K-suffix). Append " MTD" for current month.
- Dark tooltip on hover (rounded 6px, white text ~11.5px) with label + Livery + Service + Total.
- Colours: Livery `#1F9D55`, Service `#1E3A5F`.
- Toggle segmented control above chart drives data feed.

---

## 11. Design tokens

```css
/* Background / surface */
--bg:           #F8F9FA;
--surface:      #FFFFFF;
--surface-2:    #F4F5F7;

/* Borders */
--border:       #E5E7EB;
--border-soft:  #EEF0F2;

/* Text */
--text:         #111827;
--text-2:       #374151;
--muted:        #6B7280;
--muted-2:      #9CA3AF;

/* Brand */
--green:        #1F9D55;   /* primary emerald */
--green-700:    #167A40;
--green-50:     #E8F5EE;
--navy:         #1E3A5F;   /* horse / customer name colour */

/* Accents (KPI icons + status) */
--orange:       #D97706;   /* + 50: #FEF3E6 */
--blue:         #2563EB;   /* + 50: #EBF2FE */
--purple:       #7C3AED;   /* + 50: #F1ECFE */
--red:          #DC2626;   /* + 50: #FEECEC */

--radius:       8px;
--radius-lg:    12px;
```

**Typography**:
- Family: `Geist, ui-sans-serif, sans-serif` (or the codebase's system sans).
- Base: 14px / line-height 1.5.
- Numbers in KPI values, table amounts, and chart axes: `font-variant-numeric: tabular-nums`.

**Spacing**: 4 / 8 / 12 / 16 / 18 / 22 / 28 / 32 px scale.
**Shadow (card hover)**: `0 1px 2px rgba(17,24,39,.04)`.

---

## 12. PDF GENERATION — Complete Report

The header button **"Download Complete Report (PDF)"** generates a 7-page
A4-portrait PDF. See `livery-report-pdf-reference.html` for the exact
visual.

### 12.1 PDF structure

| Page | Section | Contents |
|---|---|---|
| 1 | **Cover** | Full-bleed top half: green (#1F9D55) background with StableMaster logo, kicker "Monthly Livery Report", title "Livery Report" (48pt/700), period "May 2026" (22pt/500). Bottom half: 3-cell meta strip (Period / Generated / Prepared by), Contents list with section numbers + page anchors, footer with "Confidential" notice + page number. |
| 2 | **Executive Summary** | Section runner + header; 4×2 KPI grid (same as on-screen); "Key Observations" bullet box. |
| 3 | **Revenue & Trends** | Revenue Breakdown (3-cell); 12-month stacked bar chart; Top-10 Customers list (rank + name + horse count + monthly amount). |
| 4 | **Movement — Arrivals & Departures** | Arrivals list, Departures list (empty state if none), Stable Capacity & Mix (Damess vs Al Anood cards). |
| 5–7 | **Customer Roster** | Full roster table — header repeats on every page; rows allowed to break across pages. |

Every non-cover page has:
- **Runner top**: tiny logo + "Livery Report · &lt;Month YYYY&gt;" on left, section name on right, 1px bottom border.
- **Runner bottom**: "Stable Master · ADEC Livery" on left, "Page N of 7" on right, 1px top border.

### 12.2 Recommended generation pipeline

**Headless Chromium (Puppeteer / Playwright) — recommended**

1. Backend renders the report HTML on a route protected by an internal token,
   e.g. `GET /internal/reports/livery/print?month=2026-05&token=…`. The HTML
   should be a server-rendered version of `livery-report-pdf-reference.html`
   with real data interpolated.
2. The PDF endpoint launches headless Chromium, loads that URL, waits for
   the chart to render (`page.waitForFunction(() => !!document.getElementById('monthChart').children.length)`),
   and calls:

   ```js
   await page.pdf({
     format: 'A4',
     printBackground: true,
     preferCSSPageSize: true,    // honours @page rules in the HTML
     displayHeaderFooter: false, // we draw runners in HTML
     margin: { top: 0, right: 0, bottom: 0, left: 0 },
   });
   ```

   `preferCSSPageSize: true` + `printBackground: true` are required so the
   `@page` margins and the green cover bleed render correctly.

3. Stream the buffer back as `application/pdf` with the filename
   `livery-report-<YYYY-MM>.pdf`.

**Why headless Chromium over wkhtmltopdf / PDF libraries**: the report uses
modern CSS (grid, custom properties, `print-color-adjust`, multi-page
table headers), all of which render natively in Chrome but are flaky in
wkhtmltopdf or hand-built layouts.

**Example Node + Puppeteer endpoint**:

```ts
import puppeteer from 'puppeteer';

export async function generateLiveryReportPdf(month: string): Promise<Buffer> {
  const browser = await puppeteer.launch({ headless: 'new' });
  try {
    const page = await browser.newPage();
    const token = signInternalToken();
    await page.goto(
      `${INTERNAL_BASE_URL}/internal/reports/livery/print?month=${month}&token=${token}`,
      { waitUntil: 'networkidle0' }
    );
    // Wait for chart SVG to populate (it renders client-side)
    await page.waitForFunction(
      () => document.querySelector('#monthChart')?.children.length > 0,
      { timeout: 5_000 }
    );
    return await page.pdf({
      format: 'A4',
      printBackground: true,
      preferCSSPageSize: true,
      margin: { top: 0, right: 0, bottom: 0, left: 0 },
    });
  } finally {
    await browser.close();
  }
}
```

Alternative: render the chart server-side (chart-svg via `vega-lite`,
`recharts/ssr`, or `chart.js-node-canvas`) and inline the SVG so you don't
have to `waitForFunction`.

### 12.3 Print stylesheet rules to preserve

The reference PDF HTML already includes everything you need; key bits:

```css
@page {
  size: A4 portrait;
  margin: 16mm 14mm 18mm 14mm;
}
@page :first { margin: 0; }  /* cover bleeds */

@media print {
  .page { page-break-after: always; page-break-inside: avoid; }
  .page:last-of-type { page-break-after: auto; }
  .roster-page { page-break-inside: auto; }
  table.roster thead { display: table-header-group; } /* repeat header */
  table.roster tr { page-break-inside: avoid; }
  .no-print { display: none !important; }
}

* { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
```

### 12.4 Data binding

Drive the PDF off the same `LiveryReport` API response defined in §8. The
PDF template should read every value from that payload — do not duplicate
business logic.

Per-stable capacity for the Movement page comes from `report.stables[]`
(see §8). If you don't have that yet, group `roster[]` by `stable` and
divide by your known per-stable capacity.

---

## 13. Icons

Reference uses inline outline SVG (stroke-width 2). Swap for your app's icon
set (Lucide, Phosphor, Heroicons, etc. — outline variants).

| Where | Icon |
|---|---|
| Sidebar "Livery Reports" | bar-chart |
| Topbar — print | printer |
| Topbar — Download Complete Report | file-down / file-text |
| KPI: Total / Customer Horses | horseshoe / users |
| KPI: ADEC Horses | shield-check |
| KPI: Occupancy | gauge |
| KPI: Active Customers | user |
| KPI: Active Agreements | file-text |
| KPI: Monthly Revenue | dollar-circle |
| KPI: Top Customer | trophy |
| Roster row | horseshoe (green chip) |
| Departures empty state | log-out arrow |
| Search / Download buttons | search / download |
| Month picker | calendar |

---

## 14. Responsive behaviour

- ≥1200px: KPI grid 4-up, Arrivals+Departures 2-up.
- &lt;1200px: KPI grid 2-up, Arrivals+Departures stack.
- &lt;760px: Sidebar collapses to a sheet/hamburger (use the existing app pattern); content stacks.

---

## 15. Accessibility

- All interactive elements reachable by keyboard.
- Segmented control buttons can use `role="tab"` + `aria-selected`, or plain `<button>`s.
- Chart bars: expose data via `aria-label` on the chart container or a hidden `<table>` fallback.
- Colour contrast: use `--green-700` (`#167A40`) on `--green-50` (`#E8F5EE`) for foreground text. Don't use plain `--green` for body text.

---

## 16. Bundle contents

```
design_handoff_livery_report/
├── README.md                              ← this document
├── livery-report-reference.html           ← interactive in-app reference
├── livery-report-pdf-reference.html       ← paginated A4 PDF reference
├── source-data/
│   └── livery-report-2026-05.pdf          ← original report (data source)
└── existing-system-screenshots/
    ├── 01-dashboard.png
    ├── 02-new-agreement.png
    └── 03-to-invoice.png
```

---

## 17. Acceptance checklist

- [ ] Page renders inside the existing StableMaster shell with **Livery Reports** highlighted.
- [ ] **Month picker** in the page header swaps every metric.
- [ ] 8 KPI cards in two rows of 4. **No comparison chips.** Card-specific footers only where listed in §6.2.
- [ ] Revenue Breakdown shows **Total Revenue ("All sources")**, **Livery Revenue ("Livery package")**, **Service Revenue ("Clinic, Farrier, Stores & Extras")**.
- [ ] Revenue Trend chart has three toggles: **Per Month · Last 12 / Top 10 Customers / Bottom 10 Customers**. Y-axis scales correctly for each.
- [ ] Arrivals + Departures cards appear inside the Customer Roster section, with empty-state for Departures when none.
- [ ] Roster table is searchable, filterable, and exportable to **CSV** + **PDF**.
- [ ] Topbar has a **Download Complete Report (PDF)** button that returns the 7-page PDF from §12.
- [ ] Generated PDF visually matches `livery-report-pdf-reference.html`.
- [ ] Loading and error states for the data fetch are handled gracefully.

---

_If anything is unclear, stop and ask before guessing — the reference HTMLs
are authoritative for visuals._
